package problems_2016_07_20;

public class BarProblem {

	public static int maxArea1(int[] arr) {
		if (arr == null || arr.length < 3) {
			return 0;
		}
		int res = Integer.MIN_VALUE;
		for (int i = 0; i < arr.length - 2; i++) {
			for (int j = i + 2; j < arr.length; j++) {
				res = Math.max(res, (j - i - 1) * Math.min(arr[i], arr[j]));
			}
		}
		return res;
	}

	public static int maxArea2(int[] arr) {
		if (arr == null || arr.length < 3) {
			return 0;
		}
		int l = 0;
		int r = arr.length - 1;
		int res = Integer.MIN_VALUE;
		while (l < r) {
			if (arr[l] < arr[r]) {
				res = Math.max(res, (r - l - 1) * arr[l++]);
			} else {
				res = Math.max(res, (r - l - 1) * arr[r--]);
			}
		}
		return res;
	}

	public static int[] generateRandomArray() {
		int[] arr = new int[(int) (Math.random() * 98) + 2];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = (int) (Math.random() * 200) + 2;
		}
		return arr;
	}

	public static void main(String[] args) {
		for (int i = 0; i < 1000000; i++) {
			int[] arr = generateRandomArray();
			int r1 = maxArea1(arr);
			int r2 = maxArea2(arr);
			if (r1 != r2) {
				System.out.println("What a fucking day! fuck that! man!");
			}
		}
	}

}
